package com.bpa.repository;

import com.bpa.entity.Product;
import com.bpa.entity.Product.ProductType;

import java.util.List;
//import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByType(ProductType type);
}

