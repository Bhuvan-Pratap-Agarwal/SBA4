package com.bpa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ProductTable")
public class Product 
{
	@Id
	@GeneratedValue
	private Long id;
	
	private ProductType type;

	
	public enum ProductType
	{
		MOBILE, LAPTOP
	}


	public ProductType getType() {
		return type;
	}


	public void setType(ProductType type) {
		this.type = type;
	}
	
}
