package com.bpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bpa.ProductDescriptionService.ProductDescription;

public interface ProductDescriptionRepository extends JpaRepository<ProductDescription, Long> {
}
