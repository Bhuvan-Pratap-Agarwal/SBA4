package com.bpa.ProductDescription;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductDescriptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductDescriptionApplication.class, args);
	}

}
