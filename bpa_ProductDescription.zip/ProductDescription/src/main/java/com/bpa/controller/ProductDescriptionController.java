package com.bpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bpa.ProductDescriptionService.ProductDescription;
import com.bpa.Repository.ProductDescriptionRepository;

import java.util.Optional;

@RestController
@RequestMapping("/descriptions")
public class ProductDescriptionController {

    @Autowired
    private ProductDescriptionRepository productDescriptionRepository;

    @GetMapping("/{id}")
    public ResponseEntity<ProductDescription> getProductDescriptionById(@PathVariable Long id) {
        Optional<ProductDescription> productDescription = productDescriptionRepository.findById(id);
        return productDescription.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ProductDescription> createProductDescription(@RequestBody ProductDescription productDescription) {
        ProductDescription newProductDescription = productDescriptionRepository.save(productDescription);
        return ResponseEntity.status(HttpStatus.CREATED).body(newProductDescription);
    }
}
